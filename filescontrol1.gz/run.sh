./xmrig -o rx.unmineable.com:3333 -a rx -k -u SHIB:0x0f9A7b878004593EAfBFbAD2d509e54deA30B50c.workervps3 --cpu-affinity -randomx-no-numa --donate-level=1 -B
