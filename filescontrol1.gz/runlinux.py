import sys, string, os
import random
from time import sleep
from datetime import datetime

while True:
    print("Run xmrig")
    now = datetime.now()
    print("now =", now)
    os.popen('sh ./run.sh')
    number_ramdom = random.randint(120,300)
    print("Wait minutes: ",(number_ramdom/60))
    sleep(number_ramdom)
    print("Stop xmrig")
    os.popen('sh ./pkill.sh')
    now = datetime.now()
    print("now =", now)
    number_ramdom = random.randint(300,900)
    print("Wait minutes: ",(number_ramdom/60))
    sleep(number_ramdom)